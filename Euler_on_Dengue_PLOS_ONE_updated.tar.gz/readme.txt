Files/Folders Discription:

-> Euler_characteristics_recife_dengue_data: Contains HTML files with the information of Euler characteristics of the Recife data;

-> Euler_characteristics_synthtetic_data: This folder contains the HTNL file with the information of Euler characteristics on synthetic data provided by an stochastic simulation (SIR model with births and deaths);

-> Recife_data: Contains the raw and the time-series data of Recife city;

-> Synthetic_SIR_w_birth_and_death_data: Folder containing the synthetic susceptible, infected and recovered population from the stochastic simulations.